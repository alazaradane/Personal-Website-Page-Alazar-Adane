const questions=[
    {
        question:"What is the Capital Cities of Ethiopia?",
        answers:[
            {text:"Hawasa" ,correct:false},
            {text:"Lalibela" ,correct:false},
            {text:"Addis Ababa" ,correct:true},
            {text:" Gondar" ,correct:false}
        ]
    },
    {
        question:" Which of the following is a UNESCO World Heritage Site in Ethiopia?",
        answers:[
            {text:"Laibelia" ,correct:false},
            {text:"Aksum" ,correct:false},
            {text:"Harar" ,correct:false},
            {text:"All" ,correct:true}
        ]
    },
    {
        question:"Which of the following is the lowest point in Africa?",
        answers:[
            {text:"Danakil Depression" ,correct:true},
            {text:" Omo Valley" ,correct:false},
            {text:" Simien Mountains" ,correct:false},
            {text:"Bale Mountains" ,correct:false}
        ]
    },
    {
        question:"lalibela known as the City of Churches?",
        answers:[
            {text:"true" ,correct:true},
            {text:"false" ,correct:false}
        ]
    }, {
        question:"Which of the following is home to a unique culture of indigenous peoples?",
        answers:[
            {text:"Omo valley" ,correct:true},
            {text:"Danakil Depression" ,correct:false},
            {text:"Simien Mountains" ,correct:false},
            {text:"Bale Mountains" ,correct:false}
        ]
    },
    {
        question:"Which of the following is known for its coffee production?",
        answers:[
            {text:"Sidamo" ,correct:false},
            {text:"Yirgacheffe" ,correct:false},
            {text:"Hararghe" ,correct:true},
            {text:"All ofthe above", correct:true}
        ]
    },
    {
        question:"Which of the following is the largest national park in Ethiopia?",
        answers:[
            {text:"Omo National Park" ,correct:false},
            {text:"Simien Mountains National Park" ,correct:false},
            {text:"Mago National Park" ,correct:false},
            {text:"Bale Mountains National Park" ,correct:true}
        ]
    },
    {
        question:"Which of the following is known for its rock-hewn churches?",
        answers:[
            {text:"Laliblia" ,correct:false},
            {text:"Axsum" ,correct:true},
            {text:"Harar" ,correct:false},
            {text:"Gonder" ,correct:false}
        ]
    },
    {
        question:"Which of the following is home to the Ethiopian wolf, the world's rarest canid?",
        answers:[
            {text:"Awash" ,correct:false},
            {text:"Omo" ,correct:true},
            {text:"Simien" ,correct:false},
            {text:"None of the above" ,correct:false}
        ]
    }    
];
const questionElement=document.getElementById("question");
const answerButton=document.getElementById("answer-buttons");
const nextButton=document.getElementById("next-btn");
let currentQuestionIndex = 0;
let score=0;
function StartQuiz(){
    currentQuestionIndex=0;
    score=0;
    nextButton.innerHTML="Next";
    showQuestion();
}
function showQuestion(){
    resetState();
    let currentQuestion=questions[currentQuestionIndex];
    let questionNumber=currentQuestionIndex+1;
    questionElement.innerHTML=questionNumber+". "+currentQuestion.question;

    currentQuestion.answers.forEach(answer=>{
        const button=document.createElement("button");//create a button
        button.innerHTML=answer.text;//we will add the answer
        button.classList.add("btn");//adding the class in the button
        answerButton.appendChild(button);//display button inside the div answer-buttons
        if(answer.correct){
            button.dataset.correct=answer.correct;
        }
        button.addEventListener("click",selectAnswer);
    });
}
function resetState(){
    nextButton.style.display="none";
    while(answerButton.firstChild){
        answerButton.removeChild(answerButton.firstChild);
    }
}
function selectAnswer(e){
    const selectedBtn=e.target;//store the selected answer
    const isCorrect=selectedBtn.dataset.correct==="true";//compare the selected button with true
    if(isCorrect){
        selectedBtn.classList.add("correct");//add className correct
        score++;
    }
    else{
        selectedBtn.classList.add("incorrect");//add className incorrect
    }
    Array.from(answerButton.children).forEach(button=>{//for each button will check the dataset if it is true will mark it green if it is false then it will be red and further marking is disbaled
        if(button.dataset.correct==="true"){
            button.classList.add("correct");
        }
        button.disabled=true;
    });
    nextButton.style.display="block";
}
function showScore(){
    resetState();
    questionElement.innerHTML=`You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML="PLAY AGAIN";
    nextButton.style.display="block";
}
function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex<questions.length){
        showQuestion();
    }
    else{
        showScore();
    }
}
nextButton.addEventListener("click",()=>{
    if(currentQuestionIndex< questions.length ) {
    handleNextButton();
    }
    else{
        StartQuiz();
    }
});
StartQuiz();
